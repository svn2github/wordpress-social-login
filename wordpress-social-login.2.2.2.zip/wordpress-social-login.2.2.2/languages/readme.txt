If you want to translate this plugin and you are new to WP/i18n, then we recommend check out this video:

  Localizing and Translating WordPress Plugins
  https://youtube.com/watch?v=aGN-hbMCPMg

Note: WSL uses _wsl_e() instead of _e() and _wsl__ instead of __()
